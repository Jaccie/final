#include <stdio.h>
#include "struct.h"
#include <string.h>

FILE* snapshot;
int buff[32];
int reg[32];
int HI_reg,LO_reg,HI,LO;
command comm[258];

void print_cyc(int cycle){
	fprintf(snapshot , "cycle %d\n" , cycle);
//	printf("cycle %d\n",cycle);
}

void print_pc(unsigned int PC){
	fprintf(snapshot , "PC: 0x%08X\n\n\n" , PC);
//	printf("PC: 0x%08X\n\n\n",PC);
}

void print_reg(){
	for(int i = 0 ; i < 32 ; i ++){
		if(buff[i] != reg[i]){
			fprintf(snapshot , "$%02d: 0x%08X\n" , i , buff[i]);
			//printf("$%02d: 0x%08X\n" , i , buff[i]);
			reg[i] = buff[i];
		}
	}
	if(HI_reg != HI){
		fprintf(snapshot , "$HI: 0x%08X\n" , HI_reg);
  //              printf("$HI: 0x%08X\n" , HI_reg);
                HI = HI_reg;
	}
	if(LO_reg != LO){
		fprintf(snapshot , "$LO: 0x%08X\n" , LO_reg);
    //            printf("$LO: 0x%08X\n" , LO_reg);
                LO = LO_reg;
	}
}
