#include <stdio.h>
#include "struct.h"

command comm[258];
int mf;
int HI_reg,LO_reg;
int cycle;
int result;
int num;

void EX(){
	long long int multi = 0;
//	printf("EX num:%d\n",num);
       	if(num >= 2 && comm[num].nop == 0){
//		printf("EX\n");
		if(comm[num].opcode == 0){
		switch(comm[num].func){
			case 32: //add
				result = reg[comm[num].rs] + reg[comm[num].rt];
			break;

			case 33: //addu
				result = (unsigned int)reg[comm[num].rs] +(unsigned int)reg[comm[num].rt];
			break;

			case 34: //sub
				result = reg[comm[num].rs] - reg[comm[num].rt];
			break;
			
			case 36: //and
				result = reg[comm[num].rs] & reg[comm[num].rt];
			break;
		
			case 37: //or
				result = reg[comm[num].rs] | reg[comm[num].rt];
			break;

			case 38: //Xor
				result = reg[comm[num].rs] ^ reg[comm[num].rt];
			break;

			case 39: //nor
				result = ~(reg[comm[num].rs] | reg[comm[num].rt]);
			break;

			case 40: //nand
				result = ~(reg[comm[num].rs] & reg[comm[num].rt]);
			break;

			case 42: //slt
				result = (reg[comm[num].rs] < reg[comm[num].rt]);
			break;

			case 0: //sll
				//printf("sll 0x%08X << %d = $%d: 0x%08X\n",reg_rt,comm[i].shamt,comm[i].rd,EX_DM);
				result = reg[comm[num].rt] << comm[num].shamt;
			break;

			case 2: //srl
				result = (unsigned int)reg[comm[num].rt] >> comm[num].shamt;
			break;

			case 3: //sra
				result = reg[comm[num].rt] >> comm[num].shamt;
			break;

			case 24: //mult
				{
				long long int rs = reg[comm[num].rs];
	    			long long int rt = reg[comm[num].rt];
				multi = rs * rt;
				HI_reg = multi >> 32;
            			LO_reg = (multi << 32) >> 32;
				mf = 1;}
			break;

			case 25: //multu
				{
				unsigned long long int reg1 = (unsigned)reg[comm[num].rs];
	    			unsigned long long int reg2 = (unsigned)reg[comm[num].rt];
            			unsigned long long int mult = reg1 * reg2;
	    			HI_reg = mult >> 32;
	    			LO_reg = (mult << 32) >> 32;
				mf = 1;}
			break;
			
			case 16: //mfhi
				result = HI;
				mf = 0;
			break;
	
			case 18: //mflo
				result = LO;
				mf = 0;
			break;
		}
		}//end rType

	//////////////iType//////////
	//EX is addi,lw,lh,lhu,lb,lbu,sw,sh,sb
	else if(comm[num].opcode == 8 || comm[num].opcode == 35 || comm[num].opcode == 33 || comm[num].opcode == 37 || comm[num].opcode == 32 || comm[num].opcode == 36 || comm[num].opcode == 40 || comm[num].opcode == 41 || comm[num].opcode == 43){
	
			if((comm[num].C>>15)==1)
               		comm[num].C |= 0xffff0000;
       		else
              		comm[num].C &= 0x0000ffff;			

		result = comm[num].C + reg[comm[num].rs];
	}
	//addiu andi ori nori slti
	else if(comm[num].opcode == 9 || comm[num].opcode == 12 || comm[num].opcode == 13 || comm[num].opcode == 14 || comm[num].opcode == 10){
		//addiu
		if(comm[num].opcode == 9){
			if((comm[num].C>>15)==1)
                        	comm[num].C |= 0xffff0000;
                	else
                        	comm[num].C &= 0x0000ffff;
			result = (unsigned int)comm[num].C + (unsigned int)reg[comm[num].rs];
		}
		//andi
		else if(comm[num].opcode == 12){
			comm[num].C &= 0x0000ffff;
			result = comm[num].C & reg[comm[num].rs];
		}
		//ori
		else if(comm[num].opcode == 13){
			comm[num].C &= 0x0000ffff;
                	result = comm[num].C | reg[comm[num].rs];
		}
		//nori
		else if(comm[num].opcode == 14){
			comm[num].C &= 0x0000ffff;
                	result = ~(comm[num].C | reg[comm[num].rs]);
		}
		//slti
		else if(comm[num].opcode == 10){
			if((comm[num].C>>15)==1)
                        	comm[num].C |= 0xffff0000;
                	else
                        	comm[num].C &= 0x0000ffff;
			result = (reg[comm[num].rs] < comm[num].C);
		}
	}
	//lui
	else if(comm[num].opcode == 15){
                result = comm[num].C << 16;
	}

	else if(comm[num].opcode == 4 || comm[num].opcode == 5 || comm[num].opcode == 7){
		//beq
		if(comm[num].opcode == 4){
			if((comm[num].C>>15)==1)
                        	comm[num].C |= 0xffff0000;
                	else
                        	comm[num].C &= 0x0000ffff;
		}
		//bne
		else if(comm[num].opcode == 5){
			if((comm[num].C>>15)==1)
                        	comm[num].C |= 0xffff0000;
                	else
                        	comm[num].C &= 0x0000ffff;
		}
		//bgtz
		else if(comm[num].opcode == 7){
			if((comm[num].C>>15)==1)
                        	comm[num].C |= 0xffff0000;
                	else
                        	comm[num].C &= 0x0000ffff;
		}
	}
}
//printf("preresult:%d\n",result);
}
