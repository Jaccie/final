#include <stdio.h>
#include "struct.h"
TLB iTLB[1024];
TLB dTLB[1024];
int iTLBEntries;
int dTLBEntries;
int num;
command comm[258];
data d[258];
int cycle;
int iTLBHit;
int iTLBMiss;
int dTLBHit;
int dTLBMiss;
int cycle;
unsigned int PC;
int iPageSize;

int Find_iTLB(){
	int i;
	int VPN;
	if(num >= 2) VPN = comm[num].VPN;
	else VPN = PC/iPageSize;
	for(i=0;i<iTLBEntries;i++){
		//TLB Hit!!
		if(iTLB[i].VPN == VPN && iTLB[i].valid == 1){
			iTLBHit ++;
			iTLB[i].LRU = cycle;
			comm[num].PPN = iTLB[i].PPN;
			return 1;
		}
	}
	//TLB Miss
	iTLBMiss ++;
	return 0;
}

void New_iTLB(){
	//First, find for blank space
	int i;
	int VPN;
        if(num >= 2) VPN = comm[num].VPN;
        else VPN = PC/iPageSize;
	for(i=0;i<iTLBEntries;i++){
		//There is a blank space!
		if(iTLB[i].valid == 0){
			iTLB[i].valid = 1;
			iTLB[i].VPN = VPN;
			iTLB[i].LRU = cycle;
			iTLB[i].PPN = comm[num].PPN;
			return;
		}
	}
	//No space, replacement!
	//Find the victim
	int min = iTLB[0].LRU;
	int victim = 0;
	for(i=1;i<iTLBEntries;i++){
		if(iTLB[i].LRU < min){
			min = iTLB[i].LRU;
			victim = i;
		}
	}
	//Replace the victim out
	iTLB[victim].VPN = VPN;
	iTLB[victim].valid = 1;
	iTLB[victim].LRU = cycle;
	iTLB[victim].PPN = comm[num].PPN;
}

int Find_dTLB(int dnum){
	int i;
	int VPN;
        for(i=0;i<dTLBEntries;i++){
                //TLB Hit!!
                if(dTLB[i].VPN == d[dnum].VPN && dTLB[i].valid == 1){
                        dTLBHit ++;
                        dTLB[i].LRU = cycle;
                        d[dnum].PPN = dTLB[i].PPN;
                        return 1;
                }
        }
        //TLB Miss
        dTLBMiss ++;
        return 0;
}

void New_dTLB(int dnum){
	//First, find for blank space
        int i;
        for(i=0;i<dTLBEntries;i++){
                //There is a blank space!
                if(dTLB[i].valid == 0){
                        dTLB[i].valid = 1;
                        dTLB[i].VPN = d[dnum].VPN;
                        dTLB[i].LRU = cycle;
                        dTLB[i].PPN = d[dnum].PPN;
                        return;
                }
        }
        //No space, replacement!
        //Find the victim
        int min = dTLB[0].LRU;
        int victim = 0;
        for(i=1;i<dTLBEntries;i++){
                if(dTLB[i].LRU < min){
                        min = dTLB[i].LRU;
                        victim = i;
                }
        }
        //Replace the victim out
        dTLB[victim].VPN = d[dnum].VPN;
        dTLB[victim].valid = 1;
        dTLB[victim].LRU = cycle;
        dTLB[victim].PPN = d[dnum].PPN;
}
