#include <stdio.h>
#include "struct.h"

command comm[258];
int num;
int buff[32];
int result;

void ID(){
	//printf("PC 0x%08X - add 0x%08X\n",PC,comm[0].address);
	num = (signed)(PC-comm[0].address)/4 + 2;
	//printf("ID_num:%d\n",num);
	if(num>=2){
	//	printf("ID num:%d\n",num);
		comm[num].opcode = comm[num].instruction >> 26;
	//rType
		if(comm[num].opcode == 0){
			comm[num].rs = (comm[num].instruction << 6) >> 27;
    			comm[num].rt = (comm[num].instruction << 11) >> 27;
    			comm[num].rd = (comm[num].instruction << 16) >> 27;
    			comm[num].shamt = (comm[num].instruction << 21) >> 27;
    			comm[num].func = (comm[num].instruction << 26) >> 26;
		
			comm[num].halt = 0;
			comm[num].RegWrite = 1;
			comm[num].Branch = 0;
			comm[num].RegDst = 1;
			comm[num].MemRead = 0;
			comm[num].MemtoReg = 0;
			comm[num].MemWrite = 0;
			comm[num].ALUSrc = 0;
			comm[num].nop = 0;
		
			switch(comm[num].func){
				case 32:
					comm[num].name = "add";
				break;
				case 33:
					comm[num].name = "addu";
				break;
				case 34:
					comm[num].name = "sub";
				break;
				case 36:
					comm[num].name = "and";
				break;
				case 37:
					comm[num].name = "or";
				break;
				case 38:
					comm[num].name = "xor";
				break;
				case 39:
					comm[num].name = "nor";
				break;
				case 40:
					comm[num].name = "nand";
				break;
				case 42:
					comm[num].name = "slt";
				break;
				case 0:
					comm[num].name = "sll";
				break;
				case 2:
					comm[num].name = "srl";
				break;
				case 3:
					comm[num].name = "sra";
				break;
				case 8:
					comm[num].name = "jr";
					comm[num].RegWrite = 0;
					comm[num].Branch = 1;
				
				break;
				case 24:
					comm[num].name = "mult";
				break;
				case 25:
					comm[num].name = "multu";
				break;
				case 16:
					comm[num].name = "mfhi";
				break;
				case 18:
					comm[num].name = "mflo";
				break;
			}
		}
		//iType
		else if(comm[num].opcode == 8 || comm[num].opcode == 9 || comm[num].opcode == 35 || comm[num].opcode == 33 || comm[num].opcode == 37 || comm[num].opcode == 32 || comm[num].opcode == 36 || comm[num].opcode == 40 || comm[num].opcode == 41 || comm[num].opcode == 43 || comm[num].opcode == 15 || comm[num].opcode == 12 || comm[num].opcode == 13 || comm[num].opcode == 14 || comm[num].opcode == 10 || comm[num].opcode == 4 || comm[num].opcode == 5 || comm[num].opcode == 7){
			comm[num].rs = (comm[num].instruction << 6) >> 27;
			comm[num].rt = (comm[num].instruction << 11) >> 27;
			comm[num].C = (comm[num].instruction << 16) >> 16;

			comm[num].halt = 0;
			comm[num].nop = 0;
			comm[num].RegWrite = 1;
                	comm[num].Branch = 0;
	                comm[num].RegDst = 0;
        	        comm[num].MemRead = 0;
                	comm[num].MemtoReg = 0;
         	        comm[num].MemWrite = 0;
               	 	comm[num].ALUSrc = 1;
			switch(comm[num].opcode){
				case 8:
					comm[num].name = "addi";
				
				break;
				case 9:
					comm[num].name = "addiu";
				break;
				case 35:
					comm[num].name = "lw";
					comm[num].MemRead = 1;
					comm[num].MemtoReg = 1;
//					printf("LW\n");
				break;
				case 33:
					comm[num].name = "lh";
					comm[num].MemRead = 1;
					comm[num].MemtoReg = 1;
				break;
				case 37:
                                	comm[num].name = "lhu";
                           	   	comm[num].MemRead = 1;
                          	      	comm[num].MemtoReg = 1;
				break;
				case 32:
					comm[num].name = "lb";
                       	         	comm[num].MemRead = 1;
                        	        comm[num].MemtoReg = 1;
                       	 	break;
				case 36:
					comm[num].name = "lbu";
                    	        	comm[num].MemRead = 1;
                        	        comm[num].MemtoReg = 1;
                       		break;
				case 43:
					comm[num].name = "sw";
					comm[num].RegWrite = 0;
					comm[num].MemWrite = 1;
				break;
				case 41:
					comm[num].name = "sh";
                     	         	comm[num].RegWrite = 0;
                        	        comm[num].MemWrite = 1;
                       	 	break;
				case 40:
					comm[num].name = "sb";
                       	         	comm[num].RegWrite = 0;
                        	        comm[num].MemWrite = 1;
                       	 	break;
				case 15:
					comm[num].name = "lui";
				break;
				case 12:
					comm[num].name = "andi";
				break;
				case 13:
					comm[num].name = "ori";
				break;
				case 14:
					comm[num].name = "nori";
				break;
				case 10:
					comm[num].name = "slti";
				break;
				case 4:
					comm[num].name = "beq";
					comm[num].Branch = 1;
					comm[num].RegWrite = 0;
					comm[num].ALUSrc = 0;
				
				//printf("BEQ\nrs: %d\nrt: %d\n",comm[i].rs,comm[i].rt);
					
				break;
				case 5:
					comm[num].name = "bne";
                	                comm[num].Branch = 1;
                        	        comm[num].RegWrite = 0;
                                	comm[num].ALUSrc = 0;
				
				//printf("BNE\nrs: %d\nrt: %d\n",comm[i].rs,comm[i].rt);
        	                break;
				case 7:
					comm[num].name = "bgtz";
                                	comm[num].Branch = 1;
	                                comm[num].RegWrite = 0;
        	                        comm[num].ALUSrc = 0;
                	        break;
			}
		}
		//jType
		else if(comm[num].opcode == 2 || comm[num].opcode == 3){
			comm[num].jump = (comm[num].instruction << 6) >> 6;
			comm[num].nop = 0;
			comm[num].halt = 0;
	                comm[num].RegWrite = 0;
        	        comm[num].Branch = 1;
                	comm[num].RegDst = 0;
	                comm[num].MemRead = 0;
        	        comm[num].MemtoReg = 0;
                	comm[num].MemWrite = 0;
	                comm[num].ALUSrc = 0;

			if(comm[num].opcode == 2){
				comm[num].name = "j    ";
			}
			else{
				comm[num].name = "jal  ";
				comm[num].RegWrite = 1;                    
			}
		}
		//halt
		else if(comm[num].opcode ==63){
			comm[num].halt = 1;
			comm[num].RegWrite = 0;
	                comm[num].Branch = 0;
        	        comm[num].RegDst = 0;
                	comm[num].MemRead = 0;
	                comm[num].MemtoReg = 0;
        	        comm[num].MemWrite = 0;
                	comm[num].ALUSrc = 0;
			comm[num].nop = 0;
			comm[num].name = "halt ";
		}
		//jr
		if(comm[num].opcode == 0 && comm[num].func == 8){
			PC = reg[comm[num].rs];
               	}
		//beq
		else if(comm[num].opcode == 4){
			if((comm[num].C>>15)==1)
                                comm[num].C |= 0xffff0000;
                        else
                                comm[num].C &= 0x0000ffff;				
			if(reg[comm[num].rs] == reg[comm[num].rt]){
				PC = PC + 4*comm[num].C + 4;
			}
			else PC = PC + 4;
                }
		//bne
		else if(comm[num].opcode == 5){
			//printf("BNE\n");
			if((comm[num].C>>15)==1)
               	                comm[num].C |= 0xffff0000;
                        else
                                comm[num].C &= 0x0000ffff;
			//printf("rt 0x%08X != rs 0x%08X\n",reg[comm[num].rt],reg[comm[num].rs]);
			if(reg[comm[num].rt] != reg[comm[num].rs]){
                       		PC = PC + 4*comm[num].C + 4;
				//printf("else: %d\n",comm[num].C);
				//printf("PC: 0x%08X\n",PC);
                 	}
			else PC = PC + 4;
		}
		//bgtz
		else if(comm[num].opcode == 7){
			if((comm[num].C>>15)==1)
                                comm[num].C |= 0xffff0000;
                        else
                                comm[num].C &= 0x0000ffff;

			if(reg[comm[num].rs] > 0){
			        PC = PC + 4*comm[num].C + 4;
              		}
			else PC = PC + 4;
		}
		//j
		else if(comm[num].opcode == 2){
			//printf("jump to %d.",comm[num].jump);
                        PC = comm[num].jump * 4;
                }
		//jal
		else if(comm[num].opcode == 3){
			result = PC + 4;
                        PC = comm[num].jump * 4;
               	}
	}
	else{ //if num<2
		num = 0;
	}
}
