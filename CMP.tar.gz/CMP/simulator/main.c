#include <stdio.h>
#include "struct.h"
#include <stdlib.h>
#include <string.h>
command comm[258];
int reg[32];
int num;
int cycle;
unsigned int PC;
FILE *snapshot, *report, *trace;
TLB iTLB[1024];
TLB dTLB[1024];
PTE iPTE[1024];
PTE dPTE[1024];
MEM iMEM[1024];
MEM dMEM[1024];
CH iCH[1024];
CH dCH[1024];
int iPageTableEntries;
int iPageSize;
int dPageTableEntries;
int dPageSize;
int iTLBEntries;
int dTLBEntries;
int iMemEntries;
int iMemSize;
int dMemEntries;
int dMemSize;
int iCacheBlock;
int iCacheSize;
int iCacheBlockSize;
int dCacheBlock;
int dCacheSize;
int dCacheBlockSize;
int iCacheSet;
int iCacheWay;
int dCacheSet;
int dCacheWay;
int iniDisk;
int indDisk;

int iTLBMiss;
int iTLBHit;
int dTLBMiss;
int dTLBHit;
int iPTMiss;
int iPTHit;
int dPTMiss;
int dPTHit;
int iMEMMiss;
int iMEMHit;
int dMEMMiss;
int dMEMHit;
int iCHMiss;
int iCHHit;
int dCHMiss;
int dCHHit;

int main(int argc, char** argv){
	snapshot = fopen("snapshot.rpt","w+t");
    	report = fopen("report.rpt","w+t");	
	trace = fopen("trace.rpt","w+t");

	//initialize
	iMemSize = 64;
	dMemSize = 32;
	iPageSize = 8;
	dPageSize = 16;
	iCacheSize = 16;
	dCacheSize = 16;
	iCacheBlockSize = 4;
	dCacheBlockSize = 4;
	iCacheWay = 4;
	dCacheWay = 1;

	//read input
	if(argc >= 2)
		iMemSize = atoi(argv[1]);
	if(argc >= 3)
		dMemSize = atoi(argv[2]);
	if(argc >= 4)
		iPageSize = atoi(argv[3]);
	if(argc >= 5)
		dPageSize = atoi(argv[4]);
	if(argc >= 6)
		iCacheSize = atoi(argv[5]);
	if(argc >= 7)
		iCacheBlockSize = atoi(argv[6]);
	if(argc >= 8)
		iCacheWay = atoi(argv[7]);
	if(argc >= 9)
		dCacheSize = atoi(argv[8]);
	if(argc >= 10)
		dCacheBlockSize = atoi(argv[9]);
	if(argc >= 11)
		dCacheWay = atoi(argv[10]);
//	printf("iMemSize:%d\n",iMemSize);
//	printf("dMemSize:%d\n",dMemSize);

	iPageTableEntries = 1024/iPageSize;
	dPageTableEntries = 1024/dPageSize;
	iTLBEntries = iPageTableEntries/4;
	dTLBEntries = dPageTableEntries/4;
	iMemEntries = iMemSize/iPageSize;
	dMemEntries = dMemSize/dPageSize;
	iCacheBlock = iCacheSize/iCacheBlockSize;
	dCacheBlock = dCacheSize/dCacheBlockSize;
	iCacheSet = iCacheBlock/iCacheWay;
	dCacheSet = dCacheBlock/dCacheWay;
//	printf("iCacheSet:%d\n",iCacheSet);
	for(int i=0; i<32; i++)
                reg[i]=0;
        for(int i=0; i<iTLBEntries; i++){
                iTLB[i].VPN = 0;
                iTLB[i].valid = 0;
                iTLB[i].LRU = 0;
        }
        iTLBMiss = 0;
        iTLBHit = 0;
        for(int i=0; i<dTLBEntries; i++){
                dTLB[i].VPN = 0;
                dTLB[i].valid = 0;
                dTLB[i].LRU = 0;
        }
        dTLBMiss = 0;
        dTLBHit = 0;
        for(int i=0; i<iPageTableEntries; i++){
                iPTE[i].VPN = 0;
                iPTE[i].PPN = 0;
                iPTE[i].PA = 0;
                iPTE[i].valid = 0;
                iPTE[i].LRU = 0;
        }
        iPTMiss = 0;
        iPTHit = 0;
        for(int i=0; i<dPageTableEntries; i++){
                dPTE[i].VPN = 0;
                dPTE[i].PPN = 0;
                dPTE[i].PA = 0;
                dPTE[i].valid = 0;
                dPTE[i].LRU = 0;
        }
	dPTMiss = 0;
        dPTHit = 0;
        for(int i=0; i<iMemEntries; i++){
                iMEM[i].VPN = 0;
                iMEM[i].LRU = 0;
                iMEM[i].valid = 0;
        }
        iMEMMiss = 0;
        iMEMHit = 0;
        for(int i=0; i<dMemEntries; i++){
                dMEM[i].VPN = 0;
                dMEM[i].LRU = 0;
                dMEM[i].valid = 0;
        }
        dMEMMiss = 0;
        dMEMHit = 0;
        for(int i=0; i<iCacheBlock; i++){
                iCH[i].valid = 0;
                iCH[i].tag = 0;
                iCH[i].MRU = 0;
                iCH[i].VPN = 0;
		iCH[i].set = i/iCacheWay;
        }
        iCHMiss = 0;
        iCHHit = 0;
        for(int i=0; i<dCacheBlock; i++){
                dCH[i].valid = 0;
                dCH[i].tag = 0;
                dCH[i].MRU = 0;
                dCH[i].VPN = 0;
		dCH[i].set = i/dCacheWay;
		//printf("i %d set %d\n",i,dCH[i].set);
        }
        dCHMiss = 0;
        dCHHit = 0;


	read_file();

	cycle = 0;
	num= 2;
        isHalt = 0;

        for(int i = 0 ; i < 32 ; i++){
                buff[i] = reg[i];
        }

        print_cyc(cycle);
        cycle ++;
        for(int i = 0 ; i < 32 ; i++){
                fprintf(snapshot , "$%02d: 0x%08X\n" , i , reg[i]);
                //printf("$%02d: 0x%08X\n",i,reg[i]);
        }
        fprintf(snapshot , "$HI: 0x%08X\n$LO: 0x%08X\n" , HI , LO);
        //printf("$HI: 0x%08X\n$LO: 0x%08X\n" , HI , LO);
        print_pc(PC);
//	printf("dPageSize:%d\n",dPageSize);
        while(cycle <= 500000 && isHalt == 0){
		iniDisk = 0;
		indDisk = 0;
		fprintf(trace,"%d, ",cycle);
//		printf("cycle %d\n",cycle);
                ID();
	
			for(int i = 0 ; i < 5 ; i++){
				if(i<strlen(comm[num].name)){
                     			fprintf(trace , "%c" , comm[num].name[i]);
//					printf("%c" , comm[num].name[i]);
				}
				else{
					fprintf(trace , " ");
//					printf(" ");
				}
			}
	
//		printf("\n");
		IF();
                EX();
                DM();
                WB();
		if(num>=2){
			if(comm[num].Branch == 0) PC = PC + 4;
		}
		else PC = PC + 4;
		if(isHalt == 0){
			print_cyc(cycle);
			print_reg();
			print_pc(PC);
		}
		cycle ++;
		fprintf(trace,"\n");
	/*	printf("dTLB:\n");
		for(int i=0;i<dTLBEntries;i++){
			printf("[%d].VPN %d valid %d\n",i,dTLB[i].VPN,dTLB[i].valid);
		}
		printf("dMem:\n");
		for(int i=0;i<dMemEntries;i++){
                        printf("[%d].VPN %d LRU:%d\n",i,dMEM[i].VPN,dMEM[i].LRU);
                }*/
		/*printf("dCache:\n");
		for(int i=0;i<dCacheBlock;i++){
			printf("dCH[%d].tag %d valid %d MRU %d VPN %d set %d\n",i,dCH[i].tag,dCH[i].valid,dCH[i].MRU,dCH[i].VPN,dCH[i].set);
			if(i%dCacheWay == 0) printf(" num %d",dCH[i].MRUnum);
			printf("\n");
		}*/
	//	printf("\n\n");
        }
	fprintf( report, "ICache :\n");
    	fprintf( report, "# hits: %u\n", iCHHit);
    	fprintf( report, "# misses: %u\n\n", iCHMiss);
    	fprintf( report, "DCache :\n");
    	fprintf( report, "# hits: %u\n", dCHHit);
    	fprintf( report, "# misses: %u\n\n", dCHMiss);

    	fprintf( report, "ITLB :\n");
    	fprintf( report, "# hits: %u\n", iTLBHit);
    	fprintf( report, "# misses: %u\n\n", iTLBMiss);
    	fprintf( report, "DTLB :\n");
    	fprintf( report, "# hits: %u\n", dTLBHit);
    	fprintf( report, "# misses: %u\n\n", dTLBMiss);

    	fprintf( report, "IPageTable :\n");
    	fprintf( report, "# hits: %u\n", iPTHit);
    	fprintf( report, "# misses: %u\n\n", iPTMiss);
    	fprintf( report, "DPageTable :\n");
    	fprintf( report, "# hits: %u\n", dPTHit);
    	fprintf( report, "# misses: %u\n\n", dPTMiss);

    	fclose(snapshot);
    	fclose(report);
	//printf("dTLBEntries:%d\n",dTLBEntries);
	return 0;
}
