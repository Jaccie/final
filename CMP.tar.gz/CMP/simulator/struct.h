#include <stdio.h>

void read_file();
typedef struct read_iimage{
    int i;
    unsigned int instruction;
    unsigned int address;
    unsigned int opcode;
    unsigned int rs;
    unsigned int rt;
    unsigned int rd;
    unsigned int shamt;
    unsigned int func;
    int C;
    unsigned int jump;

    int halt;
    char* name;
    int RegWrite;
    int Branch;
    int RegDst;
    int MemRead;
    int MemtoReg;
    int MemWrite;
    int ALUSrc;
    int nop;

    int VPN;
    int PPN;
    int PA;
    int offset;
}command;

typedef struct read_dimage{
	unsigned int address;
	int i;
	unsigned int value;
	int VPN;
	int PPN;
	int PA;
	int offset;
}data;

typedef struct TLBYA{
	int VPN;
	int valid;
	int LRU;
	int PPN;
}TLB;

typedef struct PageTable{
	int VPN;
	int PPN;
	int PA;
	int LRU;
	int valid;
}PTE;

typedef struct Memory{
	int VPN;
	int valid;
	int LRU;
}MEM;

typedef struct Cache{
	int valid;
	int tag;
	int VPN;
	int MRU;
	int MRUnum;
	int set;
}CH;

extern int iPageTableEntries;
extern int iPageSize;
extern int dPageTableEntries;
extern int dPageSize;
extern int iTLBEntries;
extern int dTLBEntries;
extern int iMemEntries;
extern int iMemSize;
extern int dMemEntries;
extern int dMemSize;
extern int iCacheBlock;
extern int iCacheSize;
extern int iCacheBlockSize;
extern int dCacheBlock;
extern int dCacheSize;
extern int dCacheBlockSize;
extern int iCacheSet;
extern int iCacheWay;
extern int dCacheSet;
extern int dCacheWay;
extern int iMruNum;
extern int dMruNum;
extern int iniDisk;
extern int indDisk;


extern int HI,LO;
extern int HI_reg,LO_reg;
extern int mf;
extern int cycle;
extern command comm[258];
extern data d[258];
extern TLB iTLB[1024];
extern TLB dTLB[1024];
extern PTE iPTE[1024];
extern PTE dPTE[1024];
extern MEM iMEM[1024];
extern MEM dMEM[1024];
extern CH iCH[1024];
extern CH dCH[1024];
extern int reg[32];
extern int buff[32];
extern unsigned int PC;
extern FILE *snapshot, *report, *trace;
extern int result;
extern int isHalt;
extern int num;

void IF();
void ID();
void EX();
void DM();
void WB();
void halt();

void print_cyc(int cycle);
void print_reg();
void print_pc(unsigned int PC);

int Find_iTLB();
void New_iTLB();
int Find_dTLB(int VPN);
void New_dTLB(int VPN);
int Find_iPT();
void New_iPT();
int Find_dPT(int VPN);
void New_dPT(int VPN);
void New_iMem();
void New_dMem(int VPN);
void iCache();
void dCache(int VPN);

